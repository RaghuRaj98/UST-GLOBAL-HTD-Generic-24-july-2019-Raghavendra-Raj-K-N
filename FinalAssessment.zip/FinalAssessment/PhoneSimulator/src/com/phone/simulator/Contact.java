package com.phone.simulator;

public class Contact {

	public String name;
	
	public long number;
	
	public String group;
}
