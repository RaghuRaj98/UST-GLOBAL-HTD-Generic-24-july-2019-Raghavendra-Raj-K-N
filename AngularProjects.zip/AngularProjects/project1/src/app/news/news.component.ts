import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Component({
  selector: 'app-news',
  templateUrl: './news.component.html',
  styleUrls: ['./news.component.css']
})
export class NewsComponent implements OnInit {

  businessNews: any[] =[];
  usNews: any[] = [];
  sportsNews: any[] = [];
  constructor(private http: HttpClient) {
    http.get<any>('http://newsapi.org/v2/top-headlines?category=business&apiKey=c39a1979480440fabdfb84933245b157')
    .subscribe(resData=>{
      this.businessNews=resData.articles;
      console.log(this.businessNews);
    })
    http.get<any>('https://newsapi.org/v2/top-headlines?country=us&apiKey=c39a1979480440fabdfb84933245b157')
    .subscribe(resData=>{
      this.usNews=resData.articles;
      console.log(this.usNews);
    })
    http.get<any>('http://newsapi.org/v2/top-headlines?category=sports&apiKey=c39a1979480440fabdfb84933245b157')
    .subscribe(resData=>{
      this.sportsNews=resData.articles;
      console.log(this.sportsNews);
    })
   }

  ngOnInit() {
  }

}
