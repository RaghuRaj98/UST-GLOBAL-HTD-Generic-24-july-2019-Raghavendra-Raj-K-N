import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import {HttpClientModule} from '@angular/common/http'
import {RouterModule} from '@angular/router';
import {FormsModule} from '@angular/forms';
import { AppComponent } from './app.component';
import { CarsComponent } from './cars/cars.component';
import { NewsComponent } from './news/news.component';
import { RecipesComponent } from './recipes/recipes.component';
import { MobilesComponent } from './mobiles/mobiles.component';
import { PageNotFoundComponent } from './page-not-found/page-not-found.component';
import { HeaderComponent } from './header/header.component';
import { HomeComponent } from './home/home.component';
import { from } from 'rxjs';
import { MoviesComponent } from './movies/movies.component';
import { FirebaseComponent } from './firebase/firebase.component';
import { BusinessComponent } from './business/business.component';


@NgModule({
  declarations: [
    AppComponent,
    CarsComponent,
    NewsComponent,
    RecipesComponent,
    MobilesComponent,
    PageNotFoundComponent,
    HeaderComponent,
    HomeComponent,
    MoviesComponent,
    FirebaseComponent,
    BusinessComponent
  ],
  imports: [
    BrowserModule,HttpClientModule,FormsModule,
    RouterModule.forRoot([

      { path:'', component:CarsComponent},
      { path:'news', component:NewsComponent},  
      {path :'business', component:BusinessComponent},   
      { path:'recipes', component:RecipesComponent},
      { path:'mobiles', component:MobilesComponent},
      { path :'movies', component:MoviesComponent},
      { path:'firebase', component:FirebaseComponent},
      { path:'**',component:PageNotFoundComponent},
      
  
    ])
  ],
  providers: [],
  
  bootstrap: [AppComponent]
})
export class AppModule { }
