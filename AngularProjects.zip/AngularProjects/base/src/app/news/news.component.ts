import { Component, OnInit } from '@angular/core';
import { NewsServiceService } from '../news-service.service';
import { from } from 'rxjs';
@Component({
  selector: 'app-news',
  templateUrl: './news.component.html',
  styleUrls: ['./news.component.css']
})
export class NewsComponent implements OnInit {
  newsdata: any [] = [];
  constructor(private news: NewsServiceService) { }

  ngOnInit() {
    this.news.getdata().subscribe(newsrelates => {this.newsdata = newsrelates.articles;
      console.log(this.newsdata);
      
    });
    
    
  }

}
