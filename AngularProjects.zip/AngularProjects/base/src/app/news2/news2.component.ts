import { Component, OnInit } from '@angular/core';
import {News2Service} from '../news2.service';
@Component({
  selector: 'app-news2',
  templateUrl: './news2.component.html',
  styleUrls: ['./news2.component.css']
})
export class News2Component implements OnInit {
  news2data: any[] = [];
  arr: any [] = [] ;
  constructor(private news2: News2Service) { }

  ngOnInit() {

    this.news2.getnews2().subscribe(ndata => {this.news2data = ndata.articles; } );

    this.news2.getnews2().subscribe(d=>{this.arr= d.articles;});
  }

}
