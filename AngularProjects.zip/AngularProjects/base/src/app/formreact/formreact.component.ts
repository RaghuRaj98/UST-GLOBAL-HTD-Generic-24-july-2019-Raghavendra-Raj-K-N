import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl, Validators } from '@angular/forms';

@Component({
  selector: 'app-formreact',
  templateUrl: './formreact.component.html',
  styleUrls: ['./formreact.component.css']
})
export class FormreactComponent implements OnInit {

 

  constructor() { }

  //  get fname(){
  //    return this.form.get('fname');
  // }
  // form = new FormGroup({
  //   fname : new FormControl('', Validators.required)
  // })
 get fname(){
   return this.form.get('fname');
 }

 get lname(){
   return this.form.get('lname');
  }
  form = new FormGroup({
    fname : new FormControl('', Validators.required),
    lname : new FormControl('', Validators.required)
  })
  ngOnInit() {
  }

}
