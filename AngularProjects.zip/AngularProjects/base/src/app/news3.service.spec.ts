import { TestBed } from '@angular/core/testing';

import { News3Service } from './news3.service';

describe('News3Service', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: News3Service = TestBed.get(News3Service);
    expect(service).toBeTruthy();
  });
});
