import { Injectable } from '@angular/core';
import { HttpClient} from '@angular/common/http';
@Injectable({
  providedIn: 'root'
})
export class NewsServiceService {

  constructor(private http: HttpClient) { }

  getdata() {
    return this.http.get<any>(`http://newsapi.org/v2/top-headlines?category=business&apiKey=c39a1979480440fabdfb84933245b157`);
  }
}
