import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppComponent } from './app.component';
import { FormComponent } from './form/form.component';
import {FormsModule, ReactiveFormsModule} from '@angular/forms';
import { NewsComponent } from './news/news.component';
import { RouterModule} from '@angular/router';

import { HomeComponent } from './home/home.component';

import { Forms2Component } from './forms2/forms2.component';
import { News2Component } from './news2/news2.component';
import { ParentComponent } from './parent/parent.component';
import { ChildComponent } from './child/child.component';
import { Form3Component } from './form3/form3.component';
import { News3Component } from './news3/news3.component';
import { HttpClientModule } from '@angular/common/http';
import { FormreactComponent } from './formreact/formreact.component';

@NgModule({
  declarations: [
    AppComponent,
    FormComponent,
    NewsComponent,
    HomeComponent,
    Forms2Component,
    News2Component,
    ParentComponent,
    ChildComponent,
    Form3Component,
    News3Component,
    FormreactComponent
  ],
  imports: [
    BrowserModule,
    FormsModule,
    HttpClientModule,
    ReactiveFormsModule,
    RouterModule.forRoot([
      {path: 'news', component: NewsComponent},
      {path: 'news2', component: News2Component},
      {path: 'news3', component: News3Component},
      {path: 'form3',component : Form3Component}

    ])
    // RouterModule.forRoot([
    //   {path: 'home', component: HomeComponent},
    //   {path: 'news', component: NewsComponent},
    //   {path: 'form', component: FormComponent},
    //   {path: 'news2', component: News2Component},
    //   {path: 'form2', component: Forms2Component}

    // ])
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
