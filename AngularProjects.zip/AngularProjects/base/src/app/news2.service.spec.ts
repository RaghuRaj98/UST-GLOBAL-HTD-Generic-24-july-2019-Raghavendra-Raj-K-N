import { TestBed } from '@angular/core/testing';

import { News2Service } from './news2.service';

describe('News2Service', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: News2Service = TestBed.get(News2Service);
    expect(service).toBeTruthy();
  });
});
