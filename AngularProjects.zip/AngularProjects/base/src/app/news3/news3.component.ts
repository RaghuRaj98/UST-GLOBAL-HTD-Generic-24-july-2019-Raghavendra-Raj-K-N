import { Component, OnInit } from '@angular/core';
import { News3Service } from '../news3.service';

@Component({
  selector: 'app-news3',
  templateUrl: './news3.component.html',
  styleUrls: ['./news3.component.css']
})
export class News3Component implements OnInit {

  newsd: any [] = [];
  constructor(private news: News3Service) { }

  ngOnInit() {

    this.news.getData().subscribe(newsdatasent => {this.newsd = newsdatasent.articles; });
  }

}
