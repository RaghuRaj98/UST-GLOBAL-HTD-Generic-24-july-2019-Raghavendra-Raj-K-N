import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Component({
  selector: 'app-githubapi',
  templateUrl: './githubapi.component.html',
  styleUrls: ['./githubapi.component.css']
})
export class GithubapiComponent implements OnInit {

  json: any[]=[];
 
  constructor(private http: HttpClient) {
    http.get<any>('https://api.github.com/users')
    .subscribe(resData => {
      this.json = resData;
      console.log(this.json);
    })
   
  }
  ngOnInit() {
  }

}
